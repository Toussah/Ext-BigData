/**
 * 
 */
package app;

import ui.MainWindow;


/**
 * @author billy
 *
 */
public class EntranceApp {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		new App();
		
	}


}
