/**
 * 
 */
package io;

/**
 * @author billy
 *
 */
public class InputFile {


}
