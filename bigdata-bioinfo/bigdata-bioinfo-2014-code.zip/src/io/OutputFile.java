/**
 * 
 */
package io;

/**
 * @author billy
 *
 */
public class OutputFile {


}
