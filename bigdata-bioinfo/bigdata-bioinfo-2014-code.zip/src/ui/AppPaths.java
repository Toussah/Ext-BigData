package ui;


/*
 * @author : Billy
 * Application constant paths
 */
public abstract class AppPaths {
	
	public static final String APP_INIT_BACKGROUND = "/ui/background_2.jpg" ;
	
	public static final String APP_MAIN_BACKGROUND = "/ui/background_2.jpg" ;
	
}
