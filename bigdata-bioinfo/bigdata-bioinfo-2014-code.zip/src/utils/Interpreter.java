package utils;

import java.io.IOException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import ui.AppLabels;
import ui.MainWindow;

class UrlThread implements Runnable
{
	Thread t;
	FetchURLs fu;
	JSONObject kingdom;
	String output;
	UrlThread(FetchURLs fu, JSONObject kingdom, String output)
	{
		this.fu = fu;
		this.kingdom = kingdom;
		this.output = output;
		t = new Thread(this, "Url Thread");
		t.start();
	}
	
	public void run()
	{
		try 
		{
			fu.completeUrls(kingdom, output);
		} 
		catch (JSONException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

public class Interpreter
{
	private static FetchURLs fu;
	
	public static JSONArray start_fetch_listing(){
		 String output = "BioInfo.json";
	     fu = null;
	     MainWindow w = MainWindow.getInstance();
	     try {
			fu = new FetchURLs("http://www.ncbi.nlm.nih.gov");
			w.add_to_log("Start fetch of organism listing...");
			w.set_progressBar_indeterminate();
			fu.init("/genome/browse");
			w.append_to_log(AppLabels.APP_DONE);
			w.set_progressBar_value(80);
			w.add_to_log("Saving listing...");
		    fu.sortJson(output);
		    w.set_progressBar_value(100);
			w.add_to_log(AppLabels.APP_COMPLETE);
			Thread.sleep(2000);
		} catch (IOException e) {
			w.add_to_log("Error while fetching");
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	    return fu.getOrganizedJson();
	}
	
	public static JSONArray open_json_file() {
		String output = "BioInfo.json";
		fu = null;
		JSONArray r = null;
		try {
			fu = new FetchURLs("http://www.ncbi.nlm.nih.gov");
			fu.setOrganizedJson(output);
			r = fu.getOrganizedJson();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return r;
	}
	
	public static JSONArray fetch_nuccore(int[] ids){
		return fu.getNuccoreFromIds(ids);
	}
}